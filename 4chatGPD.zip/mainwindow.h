#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "produkt.h"
#include "speicher.h"
#include "neusprodukt.h"


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    //Funktionen:


private:
    Ui::MainWindow *ui;
    Speicher& speicher = Speicher::instance();

    QHBoxLayout *hLayoutMwSt10;
    QHBoxLayout *hLayoutMwSt13;
    QHBoxLayout *hLayoutMwSt20;

    void setLayoutVisibility(const QString &mwstType, bool visible);
    QWidget *getLayoutWidget(QHBoxLayout *layout);




private slots:
    void fensterNeusProdukt();
    void beiCellChanged(int reihe, int spalte);
    void hinzufuegenLeereZeile();
    void gesammtePreisInEuroBerechnenUndSetzen();


};
#endif // MAINWINDOW_H
