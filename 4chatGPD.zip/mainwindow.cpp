#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //Produkte laden (sollte zuerst passieren)
    speicher.importJsonProdukte();

    ui->setupUi(this);
    //Knöpfe verbinden
    connect(ui->actionProdukt_hinzuf_gen, SIGNAL(triggered()), this, SLOT(fensterNeusProdukt() ));

    //Tabelle verbinden
    connect(ui->tableWidget_ProdukteZumVerkauf, SIGNAL(cellChanged(int,int)), this, SLOT(beiCellChanged(int,int)));


    //Tabellen setup
    QStringList tabelleUeBerschriftenListe = {"ArtNr","Menge","Bezeichnung","PreiProStk","Preis"};
    ui->tableWidget_ProdukteZumVerkauf->setColumnCount(tabelleUeBerschriftenListe.size());
    ui->tableWidget_ProdukteZumVerkauf->setHorizontalHeaderLabels(tabelleUeBerschriftenListe);



    ui->tableWidget_ProdukteZumVerkauf->horizontalHeader()->setSectionResizeMode(0,QHeaderView::Fixed);
    ui->tableWidget_ProdukteZumVerkauf->horizontalHeader()->setSectionResizeMode(1,QHeaderView::ResizeToContents);
    ui->tableWidget_ProdukteZumVerkauf->horizontalHeader()->setSectionResizeMode(2,QHeaderView::Stretch);
    ui->tableWidget_ProdukteZumVerkauf->horizontalHeader()->setSectionResizeMode(3,QHeaderView::ResizeToContents);
    ui->tableWidget_ProdukteZumVerkauf->horizontalHeader()->setSectionResizeMode(4,QHeaderView::ResizeToContents);



    // TODO
    QFontMetrics metrics_artnr(ui->tableWidget_ProdukteZumVerkauf->font());
    // Setze die Breite für 5 Artnr
    int breiteArtnr = metrics_artnr.horizontalAdvance("  XXXXX  ");
    qDebug() << "Breite Artnr: " << breiteArtnr;
    ui->tableWidget_ProdukteZumVerkauf->setColumnWidth(0, breiteArtnr);

    QFontMetrics metrics_preisGes(ui->tableWidget_ProdukteZumVerkauf->font());
    // Setze die Breite für 5 Artnr
    int breitePreisGes = metrics_artnr.horizontalAdvance("  XX.XXX,XX  ");
    qDebug() << "Breite PreisGes: " << breitePreisGes;
    ui->tableWidget_ProdukteZumVerkauf->setColumnWidth(4, breitePreisGes);

    hinzufuegenLeereZeile();



}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::fensterNeusProdukt()
{
    NeusProdukt nP(this);
    nP.setWindowTitle("Produkte Bearbeiten");
    nP.exec();
    return;
}

void MainWindow::hinzufuegenLeereZeile()
{
    int reihe = ui->tableWidget_ProdukteZumVerkauf->rowCount();
    ui->tableWidget_ProdukteZumVerkauf->insertRow(reihe);
    QTableWidgetItem *item = new QTableWidgetItem;
    ui->tableWidget_ProdukteZumVerkauf->setItem(reihe, 0, item);
    ui->tableWidget_ProdukteZumVerkauf->editItem(item);


}

void MainWindow::beiCellChanged(int reihe, int spalte)
{
    if(spalte == 0)
    {
        QString eingabeArtNr = ui->tableWidget_ProdukteZumVerkauf->item(reihe, spalte)->text();
        quint64 index = speicher.sucheArtNr(eingabeArtNr.toUInt());
        QList<Produkt> pL = speicher.getProdukte();

        ui->tableWidget_ProdukteZumVerkauf->setItem(reihe,2, new QTableWidgetItem(pL[index].getName()));
        ui->tableWidget_ProdukteZumVerkauf->setItem(reihe,3, new QTableWidgetItem(pL[index].getPreisAsString()));

        hinzufuegenLeereZeile();

    }
}
