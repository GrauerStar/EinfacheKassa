This Projekt is just in german at the moment.

It sould get a extrem simple Checkout program and its just for testing my QT skills. ^^
